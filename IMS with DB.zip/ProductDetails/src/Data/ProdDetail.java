package Data;

public class ProdDetail {

	public int productID;
	public String productInfo;
	public int quantity;
	public String manufacturer;
	public double cost;
	public double sale;
	
	public ProdDetail(int productID, String productInfo, int quantity, String manufacturer,
			double cost, double sale) {
		super();
		this.productID = productID;
		this.productInfo = productInfo;
		this.quantity = quantity;
		this.manufacturer = manufacturer;
		this.cost = cost;
		this.sale = sale;
	}

	public ProdDetail() {
	}

	public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getProductInfo() {
		return productInfo;
	}

	public void setProductInfo(String productInfo) {
		this.productInfo = productInfo;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public double getSale() {
		return sale;
	}

	public void setSale(double sale) {
		this.sale = sale;
	}
		
   @Override
    public String toString() {
        return "Product{" +
                "ProductID='" + productID + '\'' +
                ", ProductInfo='" + productInfo + '\'' +
                ", Quantity='" + quantity + '\'' +
                ", Manufacturer='" + manufacturer + '\'' +
                ", Cost='" + cost + '\'' +
                ", Sale='" + sale + '\'' + 
                '}';
    } 
	
}
