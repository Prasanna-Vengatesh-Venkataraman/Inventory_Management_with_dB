package Data;

import Model.Datasource;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Datasource datasource = new Datasource();
        if(!datasource.open()) {
            System.out.println("Can't open datasource");
            return;
        }

        List<ProdDetail> products = datasource.queryProducts();
        if(products == null) {
            System.out.println("No Products!");
            return;
        }

        for(ProdDetail product : products) {
            System.out.println("ID = " + product.getProductID() + ", Information = " + product.getProductInfo() + ", Quantity = " + product.getQuantity()
                                 + ", Manufacturer = " + product.getManufacturer() + ", Cost = " + product.getCost() + ", Sale = " + product.getSale());
        }
       datasource.close();
    }

}
