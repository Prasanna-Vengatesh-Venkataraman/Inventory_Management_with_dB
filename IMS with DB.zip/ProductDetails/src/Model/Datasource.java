package Model;

import Data.ProdDetail;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Datasource {
    public static final String DB_NAME              = "product.db";
    public static final String CONN_NAME            = "jdbc:sqlite:C:\\UIC\\First Sem\\IDS 401 - Business Object Programming using Java\\SQLiteStudio\\product.db";

    public static final String TABLE_PRODUCT        = "Product";
    public static final String COLUMN_PRODUCT_ID    = "ID";
    public static final String COLUMN_PRODUCT_INFO  = "Information";
    public static final String COLUMN_PRODUCT_MANU  = "Manufacturer";
    public static final String COLUMN_PRODUCT_COST  = "Cost";
    public static final String COLUMN_PRODUCT_SALE  = "Sale";
    public static final String COLUMN_PRODUCT_QUANTITY  = "Quantity";
    
    public static final String INSERT_PRODUCT = "INSERT INTO " + TABLE_PRODUCT +
            '(' + COLUMN_PRODUCT_ID + ", " + COLUMN_PRODUCT_INFO + ", " + COLUMN_PRODUCT_COST + ", " + COLUMN_PRODUCT_MANU + ", " + COLUMN_PRODUCT_SALE + ", " + COLUMN_PRODUCT_QUANTITY +
            ") VALUES(?, ?, ?, ?, ?, ?)";

    public static final String UPDATE_PRODUCT = "UPDATE " + TABLE_PRODUCT + " SET " +
            COLUMN_PRODUCT_INFO + " = ?, " +
            COLUMN_PRODUCT_MANU + " = ?," +
            COLUMN_PRODUCT_COST + " = ?, " +
            COLUMN_PRODUCT_SALE + " = ?, " +
            COLUMN_PRODUCT_QUANTITY + " = ? " +
            "WHERE " + COLUMN_PRODUCT_ID + "= ? ";

    public static final String DELETE_PRODUCT = "DELETE FROM " + TABLE_PRODUCT +
            " WHERE " + COLUMN_PRODUCT_ID + "= ? ";

    private static Connection conn;
    private static PreparedStatement updateProducts;
    private static PreparedStatement insertProducts;
    private static PreparedStatement deleteProducts;

    public static ArrayList<ProdDetail> products = new ArrayList<ProdDetail>();

    private static Datasource instance = new Datasource();

    public Datasource() {

    }

    public static Datasource getInstance() {
        return instance;
    }

    public boolean open() {
        try {
           //Establish DB connection using above connection string
            conn = DriverManager.getConnection(CONN_NAME);
           //Evaluate SQL statement upon opening the connection
            insertProducts  = conn.prepareStatement(INSERT_PRODUCT);
            updateProducts  = conn.prepareStatement(UPDATE_PRODUCT);
            deleteProducts  = conn.prepareStatement(DELETE_PRODUCT);

            return true;
        } catch(SQLException e) {
            System.out.println("Couldn't connect to database: " + e.getMessage());
            return false;
        }
    }

    public void close() {
        try {
            if(conn != null) {
                conn.close();
            }
        } catch(SQLException e) {
            System.out.println("Couldn't close connection: " + e.getMessage());
        }
    }

    public List<ProdDetail> queryProducts() {

        StringBuilder sb = new StringBuilder("SELECT * FROM ");
        sb.append(TABLE_PRODUCT); products.clear();

        try(Statement statement = conn.createStatement();
            ResultSet results = statement.executeQuery(sb.toString())) {

            while(results.next()) {
                ProdDetail product = new ProdDetail();
                product.setProductID(results.getInt(COLUMN_PRODUCT_ID));
                product.setProductInfo(results.getString(COLUMN_PRODUCT_INFO));
                product.setManufacturer(results.getString(COLUMN_PRODUCT_MANU));
                product.setCost(results.getFloat(COLUMN_PRODUCT_COST));
                product.setQuantity(results.getInt(COLUMN_PRODUCT_QUANTITY));
                product.setSale(results.getFloat(COLUMN_PRODUCT_SALE));
                products.add(product);
            }

            return products;

        } catch(SQLException e) {
            System.out.println("Query failed: " + e.getMessage());
            return null;
        }
    }

    public static boolean updateProduct(int id, String info, String manufacturer, Double cost, Double sale, int qty){

        try {
            conn.setAutoCommit(false);
            updateProducts.setString(1,info);
            updateProducts.setString(2,manufacturer);
            updateProducts.setDouble(3,cost);
            updateProducts.setDouble(4,sale);
            updateProducts.setInt(5,qty);
            updateProducts.setInt(6,id);

            int affectedRows =  updateProducts.executeUpdate();

            if(affectedRows == 1) {
                conn.commit();
                return true;
            }else {

                return false;
            }

        } catch(SQLException e) {
            System.out.println("Query failed: " + e.getMessage());
            return false;
        }

    }

    public static boolean insertProduct(int id, String info, String manufacturer, double cost, double sale, int qty){

        try {
            conn.setAutoCommit(false);
            insertProducts.setInt(1,id);
            insertProducts.setString(2,info);
            insertProducts.setDouble(3,cost);
            insertProducts.setString(4,manufacturer);
            insertProducts.setDouble(5,sale);
            insertProducts.setInt(6,qty);

            System.out.println("insert query" + insertProducts);

            int affectedRows =  insertProducts.executeUpdate();

            if(affectedRows == 1) {
                conn.commit();
                return true;
            }else {

                return false;
            }

        } catch(SQLException e) {
            System.out.println("Query failed: " + e.getMessage());
            return false;
        }

    }

    public static boolean deleteProduct(int id){

        try {
            conn.setAutoCommit(false);
            deleteProducts.setInt(1,id);

            int affectedRows =  deleteProducts.executeUpdate();

            if(affectedRows == 1) {
                conn.commit();
                return true;
            }else {

                return false;
            }

        } catch(SQLException e) {
            System.out.println("Query failed: " + e.getMessage());
            return false;
        }

    }
}
