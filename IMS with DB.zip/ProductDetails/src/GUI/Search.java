package GUI;
import Model.Datasource;

import javax.swing.*;

import Data.ProdDetail;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Search extends JFrame
{
	static JTextArea tbsearch = new JTextArea();
	static JTextArea tbpid = new JTextArea();
	static JTextArea tbprod = new JTextArea();
	static JTextArea tbcost = new JTextArea();
	static JTextArea tbmanu = new JTextArea();
	static JTextArea tbqty = new JTextArea();
	static JTextArea tbsale = new JTextArea();
	
	JButton bsearch = new JButton("SEARCH");
	JButton menu = new JButton("MENU");
	
	String[] choices = { "PRODUCT ID", "PRODUCT", "QUANTITY" , "COST PRICE", "SALE PRICE" ,"MANUFACTURER"};
	JComboBox<String> cbchoices = new JComboBox<String>(choices);
	
	public Search()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel lpid = new JLabel("PRODUCT ID");
		lpid.setFont(new Font("Arial",Font.BOLD,20));
		lpid.setBounds(60, 100, 130, 30);
		lpid.setForeground(Color.RED);
		lpid.setBackground(Color.BLACK);
		lpid.setOpaque(true);
		cp.add(lpid);
		
		tbpid.setBounds(60, 140, 130, 620);
		tbpid.setFont(new Font("Arial",Font.BOLD,20));
		tbpid.setEditable(false);
		cp.add(tbpid);
		
		JLabel lprod = new JLabel("PRODUCT");
		lprod.setFont(new Font("Arial",Font.BOLD,20));
		lprod.setBounds(210, 100, 240, 30);
		lprod.setForeground(Color.RED);
		lprod.setBackground(Color.BLACK);
		lprod.setOpaque(true);
		cp.add(lprod);
		
		tbprod.setBounds(210, 140, 240, 620);
		tbprod.setFont(new Font("Arial",Font.BOLD,20));
		tbprod.setEditable(false);
		cp.add(tbprod);
		
		JLabel lqty = new JLabel("QUANTITY");
		lqty.setFont(new Font("Arial",Font.BOLD,20));
		lqty.setBounds(470, 100, 150, 30);
		lqty.setForeground(Color.RED);
		lqty.setBackground(Color.BLACK);
		lqty.setOpaque(true);
		cp.add(lqty);
		
		tbqty.setBounds(470, 140, 150, 620);
		tbqty.setFont(new Font("Arial",Font.BOLD,20));
		tbqty.setEditable(false);
		cp.add(tbqty);
		
		
		JLabel lcost = new JLabel("COST PRICE");
		lcost.setFont(new Font("Arial",Font.BOLD,20));
		lcost.setBounds(640, 100, 190, 30);
		lcost.setForeground(Color.RED);
		lcost.setBackground(Color.BLACK);
		lcost.setOpaque(true);
		cp.add(lcost);
		
		tbcost.setBounds(640, 140, 190, 620);
		tbcost.setFont(new Font("Arial",Font.BOLD,20));
		tbcost.setEditable(false);
		cp.add(tbcost);
		
		JLabel lsales = new JLabel("SALE PRICE");
		lsales.setFont(new Font("Arial",Font.BOLD,20));
		lsales.setBounds(850, 100, 190, 30);
		lsales.setForeground(Color.RED);
		lsales.setBackground(Color.BLACK);
		lsales.setOpaque(true);
		cp.add(lsales);
		
		tbsale.setBounds(850, 140, 190, 620);
		tbsale.setFont(new Font("Arial",Font.BOLD,20));
		tbsale.setEditable(false);
		cp.add(tbsale);
		
		
		JLabel lmanu = new JLabel("MANUFACTURER");
		lmanu.setFont(new Font("Arial",Font.BOLD,20));
		lmanu.setBounds(1060, 100, 390, 30);
		lmanu.setForeground(Color.RED);
		lmanu.setBackground(Color.BLACK);
		lmanu.setOpaque(true);
		cp.add(lmanu);
		
		tbmanu.setBounds(1060, 140, 390, 620);
		tbmanu.setFont(new Font("Arial",Font.BOLD,20));
		tbmanu.setEditable(false);
		cp.add(tbmanu);
		
		
		
		tbsearch.setBounds(310, 40, 920, 40);
		tbsearch.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbsearch);
		
		cbchoices.setBounds(100, 40, 200, 40);
		cbchoices.setFont(new Font("Arial",Font.PLAIN,20));
		cp.add(cbchoices);
		
		bsearch.setBounds(1240,40,150,40);
		bsearch.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(bsearch);
		bsearch.addActionListener(act);
		
		menu.setBounds(1400, 40, 120, 40);
		menu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(menu);
		menu.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Third.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new Search();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==menu)
			{
				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource() == bsearch)
			{
				tbpid.setText(null); tbprod.setText(null); tbcost.setText(null); tbmanu.setText(null); tbqty.setText(null); tbsale.setText(null);
				
				int count = 0;
				String a = (String) cbchoices.getSelectedItem();

				switch(a)
				{
				case "PRODUCT ID":
				try {
					for(int i = 0; i< Datasource.products.size(); i++ )
					{
						if (Datasource.products.get(i).productID == Integer.parseInt(tbsearch.getText().strip()))
						{
							PrintResult(Datasource.products.get(i));
							count++;
						}

					}
					if(count == 0)
					{
						JLabel msg= new JLabel("No matches for Product ID = " + tbsearch.getText().strip());
						msg.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
					}
				}
				
				catch(IllegalArgumentException e)
				{
					WrongFormat();
				}
					break;
					
				case "PRODUCT":
				try
				{
				if(Integer.parseInt(tbsearch.getText().strip())%1 == 0)
				{
					WrongFormat();
				}
				}
				
				catch(Exception e1)
				{
					try
					{
						for(int i=0; i< Datasource.products.size(); i++ )
					
						{
							if (Datasource.products.get(i).productInfo.equalsIgnoreCase(tbsearch.getText().strip()))
							{
								PrintResult(Datasource.products.get(i));
								count++;
							}
							
						}
					
						if(count == 0)
						{
							JLabel msg= new JLabel("No matches for Product = " + tbsearch.getText().strip());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					
						catch(IllegalArgumentException e)
						{
							WrongFormat();
						}
				}
					break;
					
				case "QUANTITY":
					try
					{
						for(int i=0; i< Datasource.products.size(); i++ )
					
						{
							if (Datasource.products.get(i).quantity == Integer.parseInt(tbsearch.getText().strip()))
							{
								PrintResult(Datasource.products.get(i));
								count++;
							}
							
						}
					
						if(count == 0)
						{
							JLabel msg= new JLabel("No matches for Quantity = " + tbsearch.getText().strip());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					
					catch(IllegalArgumentException e)
					{
						WrongFormat();
					}
					
					break;
					
				case "COST PRICE":
					try
					{
						for(int i=0; i< Datasource.products.size(); i++ )
					
						{
							if (Datasource.products.get(i).cost == Double.parseDouble(tbsearch.getText().strip()))
							{
								PrintResult(Datasource.products.get(i));
								count++;
							}
							
						}
					
						if(count == 0)
						{
							JLabel msg= new JLabel("No matches for Cost Price = " + tbsearch.getText().strip());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					
					catch(IllegalArgumentException e)
					{
						WrongFormat();
					}
					
					break;
					
				case "SALE PRICE":
					try
					{
						for(int i=0; i< Datasource.products.size(); i++ )
					
						{
							if (Datasource.products.get(i).sale == Double.parseDouble(tbsearch.getText().strip()))
							{
								PrintResult(Datasource.products.get(i));
								count++;
							}
							
						}
					
						if(count == 0)
						{
							JLabel msg= new JLabel("No matches for Sale Price = " + tbsearch.getText().strip());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					
					catch(IllegalArgumentException e)
					{
						WrongFormat();
					}
					
					break;
					
					
					
				case "MANUFACTURER":
				try
				{
					if(Integer.parseInt(tbsearch.getText().strip())%1 == 0)
				{
					WrongFormat();
				}
				}
				
				catch(Exception e1)
				{
					try
					{
						for(int i=0; i< Datasource.products.size(); i++ )
						{
							if (Datasource.products.get(i).manufacturer.equalsIgnoreCase(tbsearch.getText().strip()))
							{
								PrintResult(Datasource.products.get(i));
								count++;
							}
							
						}
					
						if(count == 0)
						{
							JLabel msg= new JLabel("No matches for Manufacturer = " + tbsearch.getText().strip());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
						
						catch(IllegalArgumentException e)
						{
							WrongFormat();
						}
					break;
				}
					
						
					
				}
			}
		}
	}
	
	public static void WrongFormat()
	{
		JLabel msg= new JLabel("Wrong Format");
		msg.setFont(new Font("Arial",Font.BOLD,15));
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	}
	
	public static void PrintResult(ProdDetail a)
	{
		tbpid.append(Integer.toString(a.productID)+"\n");
		tbprod.append(a.productInfo+"\n");
		tbqty.append(Integer.toString(a.quantity)+"\n");
		tbcost.append("$ "+ Double.toString(a.cost)+"0"+"\n");
		tbsale.append("$ "+ Double.toString(a.sale)+"0"+"\n");
		tbmanu.append(a.manufacturer+"\n");
	}
}
