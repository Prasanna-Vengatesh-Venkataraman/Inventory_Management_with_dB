package GUI;

import Model.Datasource;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JFrame
{
	JButton enter = new JButton("ENTER");
	
	public GUI()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		enter.setBounds(630,500,200,50);
		enter.setFont(new Font("Arial",Font.BOLD,25));
		cp.add(enter);
		enter.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/First.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new GUI();
	}

	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==enter)
			{

				Datasource datasource = new Datasource();
				datasource.open();
				datasource.queryProducts();

				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
		        
			}
		}
	}
		
}
