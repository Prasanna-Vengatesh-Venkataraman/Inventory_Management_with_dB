package GUI;

import Model.Datasource;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Add extends JFrame
{
	JTextArea tbpid = new JTextArea();
	JTextArea tbprod = new JTextArea();
	JTextArea tbcost = new JTextArea();
	JTextArea tbmanu = new JTextArea();	
	JTextArea tbqty = new JTextArea();	
	JTextArea tbsale = new JTextArea();
	
	JButton badd = new JButton("ADD");
	JButton menu = new JButton("MENU");
	
	public Add()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel lpid = new JLabel("PRODUCT ID");
		lpid.setFont(new Font("Arial",Font.BOLD,30));
		lpid.setBounds(100, 150, 280, 40);
		lpid.setForeground(Color.RED);
		lpid.setBackground(Color.BLACK);
		lpid.setOpaque(true);
		cp.add(lpid);
		
		tbpid.setBounds(400, 150 , 900, 40);
		tbpid.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbpid);
		
		JLabel lprod = new JLabel("PRODUCT");
		lprod.setFont(new Font("Arial",Font.BOLD,30));
		lprod.setBounds(100, 250, 280, 40);
		lprod.setForeground(Color.RED);
		lprod.setBackground(Color.BLACK);
		lprod.setOpaque(true);
		cp.add(lprod);	
		
		tbprod.setBounds(400, 250 , 900, 40);
		tbprod.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbprod);
		
		JLabel qty = new JLabel("QUANTITY");
		qty.setFont(new Font("Arial",Font.BOLD,30));
		qty.setBounds(100, 350, 280, 40);
		qty.setForeground(Color.RED);
		qty.setBackground(Color.BLACK);
		qty.setOpaque(true);
		cp.add(qty);
			
		tbqty.setBounds(400, 350 , 900, 40);
		tbqty.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbqty);
		
		JLabel lcost = new JLabel("COST PRICE");
		lcost.setFont(new Font("Arial",Font.BOLD,30));
		lcost.setBounds(100, 450, 280, 40);
		lcost.setForeground(Color.RED);
		lcost.setBackground(Color.BLACK);
		lcost.setOpaque(true);
		cp.add(lcost);
			
		tbcost.setBounds(400, 450 , 900, 40);
		tbcost.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbcost);
		
		JLabel lsale = new JLabel("SALE PRICE");
		lsale.setFont(new Font("Arial",Font.BOLD,30));
		lsale.setBounds(100, 550, 280, 40);
		lsale.setForeground(Color.RED);
		lsale.setBackground(Color.BLACK);
		lsale.setOpaque(true);
		cp.add(lsale);
			
		tbsale.setBounds(400, 550 , 900, 40);
		tbsale.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbsale);
		
		
		JLabel lmanu = new JLabel("MANUFACTURER");
		lmanu.setFont(new Font("Arial",Font.BOLD,30));
		lmanu.setBounds(100, 650, 280, 40);
		lmanu.setForeground(Color.RED);
		lmanu.setBackground(Color.BLACK);
		lmanu.setOpaque(true);
		cp.add(lmanu);
		
		tbmanu.setBounds(400, 650 , 900, 40);
		tbmanu.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbmanu);
		
		badd.setBounds(670,730,150,40);
		badd.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(badd);
		badd.addActionListener(act);
		
		menu.setBounds(1400, 40, 120, 40);
		menu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(menu);
		menu.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Third.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new Add();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==menu)
			{
				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource() == badd)
			{
				try
				{
				
				int count=0;
				int pid=Integer.parseInt(tbpid.getText().strip());
				for(int i = 0; i< Datasource.products.size(); i++)
				{
					if(pid==Datasource.products.get(i).getProductID())
					{
						JLabel msg= new JLabel("Product ID = " + tbpid.getText().strip()+" already present");
						msg.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						tbpid.setText(null);
						count=1;
					}
					continue;
				}
				
				if(count!=1)
				{
					Datasource.insertProduct(pid, tbprod.getText().strip() , tbmanu.getText().strip(), Double.parseDouble(tbcost.getText().strip()), Double.parseDouble(tbsale.getText().strip()), Integer.parseInt(tbqty.getText().strip()));
					JLabel msg= new JLabel("Product successfully added");
					msg.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg,"SUCCESS",JOptionPane.PLAIN_MESSAGE);
					tbpid.setText(null); tbprod.setText(null); tbcost.setText(null); tbmanu.setText(null); tbqty.setText(null); tbsale.setText(null);
				}
				
				}
			
				catch(IllegalArgumentException e)
				{
					JLabel msg= new JLabel("Wrong Format. Kindly re-check all fields ");
					msg.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}
}
