package GUI;

import Data.ProdDetail;
import Model.Datasource;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


public class View extends JFrame
{
	JTextArea tbpid = new JTextArea();
	JTextArea tbprod = new JTextArea();
	JTextArea tbcost = new JTextArea();
	JTextArea tbmanu = new JTextArea();
	JTextArea tbqty = new JTextArea();
	JTextArea tbsale = new JTextArea();
	
	JButton menu = new JButton("MENU");
	
	JRadioButton rbpid = new JRadioButton("PRODUCT ID");
	JRadioButton rbprod = new JRadioButton("PRODUCT");
	JRadioButton rbqty = new JRadioButton("QUANTITY");
	JRadioButton rbcost = new JRadioButton("COST PRICE");
	JRadioButton rbsale = new JRadioButton("SALE PRICE");
	JRadioButton rbmanu = new JRadioButton("MANUFACTURER");
	
	ButtonGroup pdbg = new ButtonGroup();
	
	public View()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(true);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel lpid = new JLabel("PRODUCT ID");
		lpid.setFont(new Font("Arial",Font.BOLD,20));
		lpid.setBounds(10, 50, 130, 30);
		lpid.setForeground(Color.RED);
		lpid.setBackground(Color.BLACK);
		lpid.setOpaque(true);
		cp.add(lpid);
		
		tbpid.setBounds(10, 85, 130, 710);
		tbpid.setFont(new Font("Arial",Font.BOLD,18));
		tbpid.setEditable(false);
		cp.add(tbpid);
		
		JLabel lprod = new JLabel("PRODUCT");
		lprod.setFont(new Font("Arial",Font.BOLD,20));
		lprod.setBounds(160, 50, 240, 30);
		lprod.setForeground(Color.RED);
		lprod.setBackground(Color.BLACK);
		lprod.setOpaque(true);
		cp.add(lprod);
		
		tbprod.setBounds(160, 85, 240, 710);
		tbprod.setFont(new Font("Arial",Font.BOLD,18));
		tbprod.setEditable(false);
		cp.add(tbprod);
		
		JLabel lqty = new JLabel("QUANTITY");
		lqty.setFont(new Font("Arial",Font.BOLD,20));
		lqty.setBounds(420, 50, 150, 30);
		lqty.setForeground(Color.RED);
		lqty.setBackground(Color.BLACK);
		lqty.setOpaque(true);
		cp.add(lqty);
		
		tbqty.setBounds(420, 85, 150, 710);
		tbqty.setFont(new Font("Arial",Font.BOLD,18));
		tbqty.setEditable(false);
		cp.add(tbqty);
		
		JLabel lcost = new JLabel("COST PRICE");
		lcost.setFont(new Font("Arial",Font.BOLD,20));
		lcost.setBounds(590, 50, 190, 30);
		lcost.setForeground(Color.RED);
		lcost.setBackground(Color.BLACK);
		lcost.setOpaque(true);
		cp.add(lcost);
		
		tbcost.setBounds(590, 85, 190, 710);
		tbcost.setFont(new Font("Arial",Font.BOLD,18));
		tbcost.setEditable(false);
		cp.add(tbcost);
		
		JLabel lsale = new JLabel("SALE PRICE");
		lsale.setFont(new Font("Arial",Font.BOLD,20));
		lsale.setBounds(800, 50, 190, 30);
		lsale.setForeground(Color.RED);
		lsale.setBackground(Color.BLACK);
		lsale.setOpaque(true);
		cp.add(lsale);
		
		tbsale.setBounds(800, 85, 190, 710);
		tbsale.setFont(new Font("Arial",Font.BOLD,18));
		tbsale.setEditable(false);
		cp.add(tbsale);
		
		JLabel lmanu = new JLabel("MANUFACTURER");
		lmanu.setFont(new Font("Arial",Font.BOLD,20));
		lmanu.setBounds(1010, 50, 280, 30);
		lmanu.setForeground(Color.RED);
		lmanu.setBackground(Color.BLACK);
		lmanu.setOpaque(true);
		cp.add(lmanu);
		
		tbmanu.setBounds(1010, 85, 280, 710);
		tbmanu.setFont(new Font("Arial",Font.BOLD,18));
		tbmanu.setEditable(false);
		cp.add(tbmanu);
		
		menu.setBounds(1400, 40, 120, 40);
		menu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(menu);
		menu.addActionListener(act);
		
		JLabel lsort = new JLabel("SORT BY");
		lsort.setFont(new Font("Arial",Font.BOLD,30));
		lsort.setBounds(1330, 270, 140, 50);
		lsort.setForeground(Color.WHITE);
		lsort.setBackground(Color.BLACK);
		lsort.setOpaque(true);
		cp.add(lsort);
		
		rbpid.setBounds(1300, 320, 200, 50);
		rbpid.setForeground(Color.WHITE);
		rbpid.setOpaque(false);
		rbpid.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbpid);
		rbpid.addActionListener(act);
		
		rbprod.setBounds(1300, 370, 200, 50);
		rbprod.setForeground(Color.WHITE);
		rbprod.setOpaque(false);
		rbprod.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbprod);
		rbprod.addActionListener(act);
		
		rbqty.setBounds(1300, 420, 200, 50);
		rbqty.setForeground(Color.WHITE);
		rbqty.setOpaque(false);
		rbqty.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbqty);
		rbqty.addActionListener(act);
		
		rbcost.setBounds(1300, 470, 200, 50);
		rbcost.setForeground(Color.WHITE);
		rbcost.setOpaque(false);
		rbcost.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbcost);
		rbcost.addActionListener(act);
		
		rbsale.setBounds(1300, 520, 200, 50);
		rbsale.setForeground(Color.WHITE);
		rbsale.setOpaque(false);
		rbsale.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbsale);
		rbsale.addActionListener(act);
		
		rbmanu.setBounds(1300, 570, 250, 50);
		rbmanu.setForeground(Color.WHITE);
		rbmanu.setOpaque(false);
		rbmanu.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbmanu);
		rbmanu.addActionListener(act);
		
		pdbg.add(rbpid);
		pdbg.add(rbprod);
		pdbg.add(rbqty);
		pdbg.add(rbcost);
		pdbg.add(rbsale);
		pdbg.add(rbmanu);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Third.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new View();
		
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==menu)
			{
				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
			}
			
			
			if(act.getSource()==rbpid)
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Datasource.products;
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).productID > datas2.get(j).productID )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}

					Print(datas2, tbpid, tbprod, tbqty, tbcost, tbsale, tbmanu);
				}
			
			if(act.getSource()==rbprod)
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Datasource.products;
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).productInfo.toLowerCase().compareTo(datas2.get(j).productInfo.toLowerCase()) > 0 )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}					
					Print(datas2, tbpid, tbprod, tbqty, tbcost, tbsale, tbmanu);
				}
			
			if(act.getSource()==rbqty)
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Datasource.products;
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).quantity > datas2.get(j).quantity )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}

					Print(datas2, tbpid, tbprod, tbqty, tbcost, tbsale, tbmanu);
				}
			
			if(act.getSource()==rbcost)
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Datasource.products;
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).cost > datas2.get(j).cost )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}
					
					Print(datas2, tbpid, tbprod, tbqty, tbcost, tbsale, tbmanu);
				}
			
			if(act.getSource()==rbsale)
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Datasource.products;
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).sale > datas2.get(j).sale )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}

					Print(datas2, tbpid, tbprod, tbqty, tbcost, tbsale, tbmanu);
				}
			
			
			if(act.getSource()==rbmanu)
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Datasource.products;
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).manufacturer.toLowerCase().compareTo(datas2.get(j).manufacturer.toLowerCase()) > 0 )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}
					
					Print(datas2, tbpid, tbprod, tbqty, tbcost, tbsale, tbmanu);
				}
			
			}
			
		}

	
	public static void swap(ProdDetail a, ProdDetail b)
	{
		
		int temppid, tempqty; double tempcost,tempsale; String tempproductInfo, tempmanufacturer;
		
		temppid = a.productID;
		tempcost = a.cost;
		tempproductInfo = a.productInfo;
		tempmanufacturer = a.manufacturer;
		tempqty = a.quantity;
		tempsale = a.sale;
		
		a.productID = b.productID;
		a.cost = b.cost;
		a.productInfo = b.productInfo;
		a.manufacturer = b.manufacturer;
		a.quantity = b.quantity;
		a.sale = b.sale;
		
		b.productID = temppid;
		b.cost = tempcost;
		b.productInfo = tempproductInfo;
		b.manufacturer = tempmanufacturer;
		b.quantity = tempqty;
		b.sale = tempsale;
	}
	
	public static void Print (ArrayList<ProdDetail> a, JTextArea tbpid, JTextArea tbprod, JTextArea tbqty, JTextArea tbcost, JTextArea tbsale, JTextArea tbmanu)
	{
		tbpid.setText(null); tbprod.setText(null); tbcost.setText(null); tbmanu.setText(null); tbqty.setText(null); tbsale.setText(null);
		
		for(int i=0; i< a.size(); i++ )
		{
			tbpid.append(Integer.toString(a.get(i).productID)+"\n");
			tbprod.append(a.get(i).productInfo+"\n");
			tbqty.append(a.get(i).quantity+"\n");
			tbcost.append("$ "+Double.toString(a.get(i).cost)+"0"+"\n");
			tbsale.append("$ "+Double.toString(a.get(i).sale)+"0"+"\n");
			tbmanu.append(a.get(i).manufacturer+"\n");
		}
	}

}
