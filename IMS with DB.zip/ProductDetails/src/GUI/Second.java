package GUI;
import Model.Datasource;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Second extends JFrame
{
	
	JButton view = new JButton("VIEW");
	JButton search = new JButton("SEARCH");
	JButton add = new JButton("ADD");
	JButton update = new JButton("UPDATE");
	JButton delete = new JButton("DELETE");
	
	public Second()
	{
		setExtendedState(MAXIMIZED_BOTH);
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel title = new JLabel("ACTION TO BE PERFORMED");
		title.setBounds(280, 30, 1100, 100);
		title.setFont(new Font("Lucida Calligraphy",Font.BOLD,60));
		title.setForeground(Color.BLACK);
		cp.add(title);
		
		view.setBounds(400,200,800,50);
		view.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(view);
		view.addActionListener(act);
		
		search.setBounds(400,300,800,50);
		search.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(search);
		search.addActionListener(act);
		
		update.setBounds(400,400,800,50);
		update.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(update);
		update.addActionListener(act);
		
		add.setBounds(400,500,800,50);
		add.setFont(new Font("Arial",Font.BOLD,20));
		add.addActionListener(act);
		cp.add(add);
		
		delete.setBounds(400,600,800,50);
		delete.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(delete);
		delete.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Second.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		setVisible(true);
	}

	public static void main(String[] args) 
	{
		new Second();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==view)
			{
				Datasource datasource = new Datasource();
				datasource.open();
				datasource.queryProducts();
				
				View a = new View();
				a.setVisible(true);
				
				
				/*for(int i=0; i< Data.ProductDetailsUsingList.datas.size(); i++ )
				{
					a.tbpid.append(Integer.toString(Data.ProductDetailsUsingList.datas.get(i).productID)+"\n");
					a.tbprod.append(Data.ProductDetailsUsingList.datas.get(i).productInfo+"\n");
					a.tbcost.append("$ "+Double.toString(Data.ProductDetailsUsingList.datas.get(i).cost)+"0"+"\n");
					a.tbmanu.append(Data.ProductDetailsUsingList.datas.get(i).manufacturer+"\n");
				}*/


				for(int i=0; i< Datasource.products.size(); i++ )
				{
					a.tbpid.append(Integer.toString(Datasource.products.get(i).getProductID())+"\n");
					a.tbprod.append(Datasource.products.get(i).getProductInfo()+"\n");
					a.tbcost.append("$ "+Double.toString(Datasource.products.get(i).getCost())+"0"+"\n");
					a.tbmanu.append(Datasource.products.get(i).getManufacturer()+"\n");
					a.tbsale.append("$ "+Double.toString(Datasource.products.get(i).getSale())+"0"+"\n");
					a.tbqty.append(Integer.toString(Datasource.products.get(i).getQuantity())+"\n");
				}


				setVisible(false);
			}
			
			if(act.getSource()==search)
			{
				Search a = new Search();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==update)
			{
				Update a = new Update();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==add)
			{
				Add a = new Add();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource()==delete)
			{
				Delete a = new Delete();
				a.setVisible(true);
				setVisible(false);
			}
		}
	}

}
